import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-properties',
  standalone: false,
  templateUrl: './manage-properties.component.html',
  styleUrl: './manage-properties.component.css'
})
export class ManagePropertiesComponent {

}
